import sqlite3

import pytest

from sql_guard import SQLGuardError, open_read_only, run_read_only_query, validate_sql


@pytest.mark.parametrize("sql,code", [
    ("DELETE FROM inventory", "NOT_A_SELECT"),
    ("UPDATE inventory SET stock_on_hand = 0", "NOT_A_SELECT"),
    ("DROP TABLE inventory", "NOT_A_SELECT"),
    ("PRAGMA table_info(inventory)", "NOT_A_SELECT"),
    ("ATTACH DATABASE 'x.db' AS x", "NOT_A_SELECT"),
    ("SELECT 1; DROP TABLE inventory", "MULTIPLE_STATEMENTS"),
    ("SELECT 1 /* harmless */ ; DELETE FROM inventory", "MULTIPLE_STATEMENTS"),
    ("WITH x AS (SELECT 1) DELETE FROM inventory", "FORBIDDEN_KEYWORD"),
    ("SELECT * FROM inventory WHERE 1=1 -- \n; DROP TABLE products", "MULTIPLE_STATEMENTS"),
    ("SELECT load_extension('evil.so')", "FORBIDDEN_KEYWORD"),
    ("", "EMPTY_QUERY"),
    ("SELECT 'unterminated", "UNTERMINATED_LITERAL"),
])
def test_static_validation_rejects(sql, code):
    with pytest.raises(SQLGuardError) as e:
        validate_sql(sql)
    assert e.value.code == code


def test_keywords_inside_string_literals_are_not_false_positives(db_path):
    res = run_read_only_query("SELECT COUNT(*) AS n FROM products WHERE name = 'DROP TABLE; DELETE'", db_path=db_path)
    assert res["rows"] == [{"n": 0}]


def test_with_select_is_allowed(db_path):
    res = run_read_only_query("WITH t AS (SELECT branch_id FROM branches) SELECT COUNT(*) AS n FROM t", db_path=db_path)
    assert res["rows"][0]["n"] == 5


@pytest.mark.parametrize("sql", [
    "DELETE FROM inventory",
    "UPDATE inventory SET stock_on_hand = 0",
    "INSERT INTO branches VALUES ('Z','x','y')",
    "CREATE TABLE pwned (a)",
    "DROP TABLE inventory",
    "ATTACH DATABASE ':memory:' AS x",
    "PRAGMA writable_schema = ON",
    "SELECT * FROM sqlite_master",
])
def test_engine_layers_block_even_if_static_validation_is_bypassed(db_path, sql):
    with pytest.raises(SQLGuardError) as e:
        run_read_only_query(sql, db_path=db_path, validate=False)
    assert e.value.code in {"NOT_AUTHORIZED", "READ_ONLY"}
    assert sqlite3.connect(db_path).execute("SELECT COUNT(*) FROM inventory").fetchone()[0] > 0


def test_read_only_connection_refuses_writes_without_authorizer(db_path):
    conn = open_read_only(db_path)
    with pytest.raises(sqlite3.OperationalError):
        conn.execute("DELETE FROM inventory")


def test_row_cap_and_truncation_flag(db_path):
    res = run_read_only_query("SELECT * FROM daily_sales", db_path=db_path, max_rows=50)
    assert res["row_count"] == 50 and res["truncated"] is True


def test_runaway_query_is_aborted(db_path):
    with pytest.raises(SQLGuardError) as e:
        run_read_only_query("SELECT COUNT(*) FROM daily_sales a, daily_sales b, daily_sales c", db_path=db_path)
    assert e.value.code == "QUERY_TOO_EXPENSIVE"


def test_empty_result_is_explicit(db_path):
    res = run_read_only_query("SELECT * FROM daily_sales WHERE sale_date = '1999-01-01'", db_path=db_path)
    assert res["status"] == "NO_RECORDS" and res["rows"] == []
