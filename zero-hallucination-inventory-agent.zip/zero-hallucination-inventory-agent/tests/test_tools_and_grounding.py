from grounding import check_answer
from tools import TOOLS, anthropic_tools, dispatch_tool, openai_tools


def test_tool_specs_are_strict_and_portable():
    for spec, a, o in zip(TOOLS, anthropic_tools(), openai_tools()):
        assert a["strict"] is True and a["input_schema"]["additionalProperties"] is False
        assert set(a["input_schema"]["required"]) == set(a["input_schema"]["properties"])
        assert o["type"] == "function" and o["function"]["parameters"] == a["input_schema"]
    assert [t.name for t in TOOLS] == ["get_low_stock_by_branch", "get_daily_sales_summary", "execute_safe_read_only_sql"]


def test_low_stock_matches_raw_sql(db_path):
    res = dispatch_tool("get_low_stock_by_branch", {"branch_id": "B", "severity": "all", "limit": 200}, db_path=db_path)
    raw = dispatch_tool("execute_safe_read_only_sql", {"query":
          "SELECT COUNT(*) AS n FROM inventory WHERE branch_id='B' AND stock_on_hand <= min_stock_alert"}, db_path=db_path)
    assert res["status"] == "OK" and res["total_matching"] == raw["rows"][0]["n"] == len(res["rows"])
    assert all(r["stock_on_hand"] <= r["min_stock_alert"] for r in res["rows"])


def test_no_records_is_explicit(db_path):
    res = dispatch_tool("get_low_stock_by_branch", {"branch_id": "C", "severity": "all", "limit": 10}, db_path=db_path)
    assert res["status"] == "NO_RECORDS" and "Do not estimate" in res["message"]
    sales = dispatch_tool("get_daily_sales_summary", {"sale_date": "2019-01-01", "branch_id": "ALL"}, db_path=db_path)
    assert sales["status"] == "NO_RECORDS"
    assert sales["available_date_range"] == {"first": "2026-10-14", "last": "2026-11-12"}


def test_sales_totals_add_up(db_path):
    res = dispatch_tool("get_daily_sales_summary", {"sale_date": "latest", "branch_id": "ALL"}, db_path=db_path)
    assert res["resolved_date"] == "2026-11-12" and len(res["rows"]) == 5
    assert round(sum(r["revenue"] for r in res["rows"]), 2) == res["totals"]["revenue"]


def test_invalid_arguments_rejected_not_raised(db_path):
    assert dispatch_tool("get_low_stock_by_branch", {"branch_id": "Z", "severity": "all", "limit": 5}, db_path=db_path)["status"] == "REJECTED"
    assert dispatch_tool("get_low_stock_by_branch", {"branch_id": "A"}, db_path=db_path)["status"] == "REJECTED"
    assert dispatch_tool("drop_everything", {}, db_path=db_path)["status"] == "REJECTED"
    assert dispatch_tool("execute_safe_read_only_sql", {"query": "DELETE FROM inventory"}, db_path=db_path)["status"] == "REJECTED"


def test_grounding_accepts_copied_and_formatted_values():
    ev = [{"rows": [{"revenue": 27506.82, "units": 1982, "sku": "SKU-1162"}]}]
    assert check_answer("Branch A made $27,506.82 on 1,982 units; top SKU-1162.", ev).grounded


def test_grounding_flags_fabricated_numbers():
    ev = [{"rows": [{"revenue": 27506.82}]}]
    rep = check_answer("Branch A made $27,506.82, up 14.5% vs last week (about 31,000 next week).", ev)
    assert not rep.grounded and set(rep.ungrounded) == {"14.5", "31000"}
