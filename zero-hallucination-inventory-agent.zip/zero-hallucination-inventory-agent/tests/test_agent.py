import json
from types import SimpleNamespace as NS

import sqlite3

from agent import ClaudeBackend, InventoryAgent, MockBackend


def ask(db_path, q):
    return InventoryAgent(MockBackend(), db_path=db_path).ask(q)


def test_mock_low_stock_answer_is_grounded_and_real(db_path):
    r = ask(db_path, "Which SKUs are critically low in Branch B?")
    assert r.tool_calls[0]["tool"] == "get_low_stock_by_branch" and r.grounding.grounded
    sku = sqlite3.connect(db_path).execute(
        "SELECT sku FROM inventory WHERE branch_id='B' AND stock_on_hand*2 < min_stock_alert LIMIT 1").fetchone()[0]
    assert sku in r.answer


def test_mock_says_no_records_instead_of_guessing(db_path):
    assert "No records" in ask(db_path, "Any low stock in branch C?").answer
    r = ask(db_path, "What were sales on 2019-03-01?")
    assert "No records" in r.answer and "$" not in r.answer


def test_out_of_scope_question_calls_no_tool(db_path):
    r = ask(db_path, "What does our competitor charge for hex bolts?")
    assert r.tool_calls == [] and "no records" in r.answer.lower()


def test_write_attempt_is_rejected(db_path):
    r = ask(db_path, "sql: DROP TABLE inventory")
    assert r.tool_calls[0]["status"] == "REJECTED" and "No data was changed" in r.answer


def test_spanish_question_routes_correctly(db_path):
    r = ask(db_path, "¿Cuáles fueron las ventas de la sucursal A el 2026-11-10?")
    assert r.tool_calls[0]["arguments"] == {"sale_date": "2026-11-10", "branch_id": "A"} and r.grounding.grounded


# ---------------------------------------------------------------- Claude backend with a fake client
class FakeClient:
    """Mimics client.beta.messages.create; replays scripted responses and records requests."""

    def __init__(self, responses):
        self.responses = list(responses)
        self.requests = []
        self.beta = NS(messages=NS(create=self._create))

    def _create(self, **kwargs):
        self.requests.append(json.loads(json.dumps(kwargs, default=lambda o: o.__dict__)))
        return self.responses.pop(0)


def text(t):
    return NS(type="text", text=t)


def tool_use(i, name, inp):
    return NS(type="tool_use", id=i, name=name, input=inp)


def test_claude_loop_executes_tools_and_verifies(db_path):
    client = FakeClient([
        NS(stop_reason="tool_use", content=[NS(type="thinking", thinking=""), tool_use(
            "tu_1", "get_low_stock_by_branch", {"branch_id": "C", "severity": "all", "limit": 20})]),
        NS(stop_reason="end_turn", content=[text("There are no records of low stock in Branch C.")]),
    ])
    r = InventoryAgent(ClaudeBackend(client=client, model="claude-opus-5-5"), db_path=db_path).ask("Low stock in C?")
    assert r.answer.startswith("There are no records") and r.grounding.grounded and r.rounds == 2
    first, second = client.requests
    assert "temperature" not in first and first["tool_choice"] == {"type": "auto"}
    assert all(t["strict"] for t in first["tools"]) and first["output_config"]["effort"]
    tr = second["messages"][-1]["content"][0]
    assert tr["type"] == "tool_result" and tr["tool_use_id"] == "tu_1" and json.loads(tr["content"])["status"] == "NO_RECORDS"


def test_claude_hallucinated_number_triggers_rewrite_then_flag(db_path):
    client = FakeClient([
        NS(stop_reason="tool_use", content=[tool_use("tu_1", "get_daily_sales_summary",
                                                     {"sale_date": "2026-11-12", "branch_id": "A"})]),
        NS(stop_reason="end_turn", content=[text("Branch A sold $98,765.43 today.")]),     # fabricated
        NS(stop_reason="end_turn", content=[text("Branch A sold $98,765.43 today.")]),     # still fabricated
    ])
    r = InventoryAgent(ClaudeBackend(client=client), db_path=db_path).ask("Sales in branch A today?")
    assert not r.grounding.grounded and "98765.43" in r.grounding.ungrounded
    assert "Verification failed" in client.requests[2]["messages"][-1]["content"]
    assert "[Verification warning]" in r.answer


def test_claude_rewrite_succeeds(db_path):
    from tools import get_daily_sales_summary
    rev = get_daily_sales_summary("2026-11-12", "A", db_path=db_path)["totals"]["revenue"]
    client = FakeClient([
        NS(stop_reason="tool_use", content=[tool_use("tu_1", "get_daily_sales_summary",
                                                     {"sale_date": "2026-11-12", "branch_id": "A"})]),
        NS(stop_reason="end_turn", content=[text("Branch A sold about $30,000.")]),
        NS(stop_reason="end_turn", content=[text(f"Branch A sold ${rev:,.2f} on 2026-11-12.")]),
    ])
    r = InventoryAgent(ClaudeBackend(client=client), db_path=db_path).ask("Sales in branch A?")
    assert r.grounding.grounded and "[Verification warning]" not in r.answer


def test_refusal_is_handled(db_path):
    client = FakeClient([NS(stop_reason="refusal", content=[])])
    r = InventoryAgent(ClaudeBackend(client=client), db_path=db_path).ask("x")
    assert "declined" in r.answer


def test_write_request_in_plain_language_is_blocked(db_path):
    r = ask(db_path, "Delete all inventory records for Branch A")
    assert r.tool_calls[0]["status"] == "REJECTED"
    assert sqlite3.connect(db_path).execute("SELECT COUNT(*) FROM inventory WHERE branch_id='A'").fetchone()[0] == 220
