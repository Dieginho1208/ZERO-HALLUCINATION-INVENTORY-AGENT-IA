from types import SimpleNamespace as NS

from daily_digest import build_digest, to_slack, to_whatsapp


class FakeLLM:
    name = "claude"

    def __init__(self, text):
        self.text = text

    def complete(self, system, prompt):
        return self.text


def test_demo_digest_is_grounded_and_formatted(db_path):
    d = build_digest("2026-11-12", db_path=db_path)
    assert d.summary_source.startswith("template") and d.grounding["grounded"]
    assert 4 <= len(d.bullets) <= 7 and all(b.startswith("• ") for b in d.bullets)
    slack = to_slack(d)
    assert slack["blocks"][0]["type"] == "header" and "Daily Ops Digest" in slack["text"]
    wa = to_whatsapp(d, to="5218100000000")
    assert wa["messaging_product"] == "whatsapp" and wa["text"]["body"].startswith("*Daily Ops Digest")


def test_llm_summary_used_when_grounded(db_path):
    base = build_digest("2026-11-12", db_path=db_path)
    llm_text = "\n".join(base.bullets)
    d = build_digest("2026-11-12", db_path=db_path, backend=FakeLLM(llm_text))
    assert d.summary_source == "llm"


def test_hallucinating_llm_falls_back_to_template(db_path):
    d = build_digest("2026-11-12", db_path=db_path, backend=FakeLLM("• Revenue grew 23.7% to $1,234,567.00"))
    assert d.summary_source == "template (LLM output failed grounding)"
    assert "23.7" in d.grounding["ungrounded_values"]


def test_no_sales_day_reports_no_records(db_path):
    d = build_digest("2020-01-01", db_path=db_path)
    assert "no records" in d.bullets[0].lower()
