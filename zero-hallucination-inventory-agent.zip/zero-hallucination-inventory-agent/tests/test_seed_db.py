import sqlite3


def test_tables_and_volumes(db_path):
    conn = sqlite3.connect(db_path)
    n = lambda sql: conn.execute(sql).fetchone()[0]
    assert n("SELECT COUNT(*) FROM branches") == 5
    assert n("SELECT COUNT(*) FROM products") >= 200
    assert n("SELECT COUNT(*) FROM inventory") == 5 * n("SELECT COUNT(*) FROM products")
    assert n("SELECT COUNT(DISTINCT sale_date) FROM daily_sales") == 30
    assert n("SELECT COUNT(DISTINCT status) FROM dispatches") >= 4
    assert n("SELECT COUNT(*) FROM inventory WHERE stock_on_hand <= min_stock_alert") > 0


def test_branch_c_is_fully_stocked_for_no_records_demo(db_path):
    conn = sqlite3.connect(db_path)
    assert conn.execute("SELECT COUNT(*) FROM inventory WHERE branch_id='C' AND stock_on_hand <= min_stock_alert").fetchone()[0] == 0


def test_seed_is_deterministic(tmp_path, db_path):
    import seed_db
    from conftest import REF_DATE
    other = seed_db.seed(tmp_path / "x.db", end_date=REF_DATE, days=30)
    q = "SELECT SUM(stock_on_hand), (SELECT ROUND(SUM(revenue),2) FROM daily_sales) FROM inventory"
    assert sqlite3.connect(other).execute(q).fetchone() == sqlite3.connect(db_path).execute(q).fetchone()
