import sys
from datetime import date
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

import seed_db  # noqa: E402

REF_DATE = date(2026, 11, 12)


@pytest.fixture(scope="session")
def db_path(tmp_path_factory) -> Path:
    return seed_db.seed(tmp_path_factory.mktemp("db") / "inventory.db", end_date=REF_DATE, days=30)
